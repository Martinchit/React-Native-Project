module.exports = {

    nutritionix: {
      'x-app-key':'0cc29202aed5d97a53a5d8a530346f87',
      'x-app-id':'a0662efe',
      'Content-ype':'application/json'
    }
};